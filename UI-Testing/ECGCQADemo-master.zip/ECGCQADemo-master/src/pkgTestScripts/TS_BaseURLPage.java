package pkgTestScripts;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import pkgConfigFiles.WebDriverSetupFile;
import pkgWebPages.BaseURLPage;

public class TS_BaseURLPage {
	static String osName;
    public static WebDriver driverMain;
	String address;
	BaseURLPage objBaseURL=new BaseURLPage();
	
	
	@BeforeSuite
	public static void launchURL()
	{
		osName=System.getenv("OS");
		System.out.println("Identified OS: "+osName);	  
		
		driverMain=WebDriverSetupFile.setupDriver(osName,"Firefox"); /**Changed**/
	}
	
	@Test
	  public void testHomePage() throws Exception {
		  
		  
			objBaseURL.clickDesiredLink(driverMain);
			
			/*
			 * SoftAssert objVerify = new SoftAssert(); objVerify.assertEquals(address,
			 * "Addess1"); objVerify.assertAll();
			 */
		  
	  }
	
	
	@AfterSuite
	public void afterMethodExec() throws InterruptedException
	{
		Thread.sleep(10000);
		driverMain.close();
	}

	
	
	
	
}

package pkgTestScripts;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import pkgWebPages.DataProviderClass;
import pkgWebPages.HRMainPage;

public class TS_HRMainPage {
	WebDriver driver;

	
	
	@Test(dataProvider = "userDetails",dataProviderClass=DataProviderClass.class)
	public void testAddEmployee(String eid,String fname,String mname,String lname,String desig,String etype,String dob,String doj) throws Exception
	{
		
		driver=TS_BaseURLPage.driverMain;	
		HRMainPage objHR=new HRMainPage();
		objHR.addEmployee(eid,fname,mname,lname,desig,etype,dob,doj);
		
	}

}

package pkgTestScripts;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import pkgWebPages.DeleteEmp;

public class TS_DeleteEmp {
	WebDriver driver;
	
	
	
	@Test
	public void testDelEmployee()
	{
		driver=TS_BaseURLPage.driverMain;
		DeleteEmp objDel=new DeleteEmp();	
		objDel.delEmployee();
		
	}
	
	
}

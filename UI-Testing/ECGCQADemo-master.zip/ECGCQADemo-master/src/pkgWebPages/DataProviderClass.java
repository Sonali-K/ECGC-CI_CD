package pkgWebPages;

import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.testng.annotations.DataProvider;

import au.com.bytecode.opencsv.CSVReader;

public class DataProviderClass {

	
	@DataProvider(name = "userDetails")
	  public static Object[][] readCsv() throws IOException {
	     CSVReader csvReader = new CSVReader(new FileReader(System.getProperty("user.dir")+"/EmpTestData.csv"),',', '\'', 1);
		  List<String[]> csvData=csvReader.readAll();
	      Object[][] csvDataObject=new Object[csvData.size()][9];
	      for (int i=0;i<csvData.size();i++) {
	          csvDataObject[i]=csvData.get(i);
	      }
	      return  csvDataObject;
	  }
}

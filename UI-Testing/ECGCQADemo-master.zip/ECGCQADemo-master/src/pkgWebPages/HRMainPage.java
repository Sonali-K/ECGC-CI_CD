package pkgWebPages;

import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import pkgConfigFiles.PropertiesSetupFile;
import pkgTestScripts.TS_BaseURLPage;

public class HRMainPage {
	
	Properties propertiesObj=new Properties();
	PropertiesSetupFile objPropSetup=new PropertiesSetupFile();
	FileInputStream objFile;
	WebDriver driver;
	
	
	public void addEmployee( String eid, String fname, String mname, String lname, String desig, String etype, String dob, String doj) throws Exception
	{	
		
		driver=TS_BaseURLPage.driverMain;
		objFile=objPropSetup.loadObjFile("BaseURLPage");        	
	 	propertiesObj.load(objFile);
	 	Thread.sleep(4000);
	 	driver.findElement(By.cssSelector(".fa-plus")).click();
	 	Thread.sleep(3000);
	 	driver.findElement(By.id("empId")).sendKeys(eid);
	 	driver.findElement(By.id("firstName")).sendKeys(fname);
	 	driver.findElement(By.id("midName")).sendKeys(mname);
	 	driver.findElement(By.id("lastName")).sendKeys(lname);
	 	driver.findElement(By.id("designation")).sendKeys(desig);
	 	driver.findElement(By.id("empType")).sendKeys(etype);
	 	driver.findElement(By.id("dob")).sendKeys("2020-01-12");
	 	driver.findElement(By.id("doj")).sendKeys("2020-06-18");
	 	driver.findElement(By.cssSelector(".btn-primary")).click();//submit button
	 		 	
	}
	
}

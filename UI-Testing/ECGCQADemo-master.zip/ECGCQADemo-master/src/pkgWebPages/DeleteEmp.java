package pkgWebPages;

import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pkgConfigFiles.PropertiesSetupFile;
import pkgTestScripts.TS_BaseURLPage;

public class DeleteEmp {
	
	Properties propertiesObj=new Properties();
	PropertiesSetupFile objPropSetup=new PropertiesSetupFile();
	FileInputStream objFile;
	WebDriver driver;
	
	public void delEmployee()
	{
		driver=TS_BaseURLPage.driverMain;
		driver.findElement(By.linkText("Delete")).click();
	}
}

package pkgWebPages;

import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import pkgConfigFiles.PropertiesSetupFile;

public class BaseURLPage {

	Properties propertiesObj=new Properties();
	PropertiesSetupFile objPropSetup=new PropertiesSetupFile();
	FileInputStream objFile;
	WebElement element;
	
	public void clickDesiredLink(WebDriver driver) throws Exception
	{	
		objFile=objPropSetup.loadObjFile("BaseURLPage");        	
	 	propertiesObj.load(objFile);
		driver.findElement(By.cssSelector(propertiesObj.getProperty("hrDetails"))).click();
	
	}
}

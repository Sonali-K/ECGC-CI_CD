/**  
 	 AUTHOR     : AKHILESH
 	 DESCRIPTION: This file will return the WebDriver object which will hold the browser instance to use in the project and load
 	 the base URL of the AUT.
**/

package pkgConfigFiles;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class WebDriverSetupFile
{
	static String driverPath;
    static WebDriver driver;

	public static WebDriver setupDriver(String osName,String browser)
	{
		if(osName.contains("Windows"))		
			driverPath="C:/geckodriver.exe";
		else 
			driverPath=null;
		
		switch(browser)
		{
			case "Firefox":
				System.setProperty("webdriver.gecko.driver",driverPath);
				driver=new FirefoxDriver();
				driver.manage().timeouts().implicitlyWait(1,TimeUnit.SECONDS);
				driver.get("http://10.212.0.72:8082/");
				return driver;
					
			case "Chrome":
				System.setProperty("webdriver.chrome.driver",driverPath);
				driver=new ChromeDriver();
				driver.manage().timeouts().implicitlyWait(1,TimeUnit.SECONDS);
				driver.get("http://10.212.0.72:8082/");
				return driver;
				
			case "IE":
				System.setProperty("webdriver.ie.driver",driverPath);
				driver=new InternetExplorerDriver();
				driver.manage().timeouts().implicitlyWait(1,TimeUnit.SECONDS);
				driver.get("http://10.212.0.72:8082/");
				return driver;
				
			default:
				return null;
		}
    }
}